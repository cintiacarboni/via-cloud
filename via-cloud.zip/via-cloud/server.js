import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const port = process.env.PORT || 8080;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Endpoint para el chat
app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;

    const completion = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "Eres VIA, una asistente turística inteligente para Argentina. Respondes claro, breve y práctico. Ayudas con destinos, clima, alojamiento, rutas, transporte, costos y traducción básica. No inventes links de reserva.",
        },
        { role: "user", content: message },
      ],
    });

    const reply = completion.choices[0].message.content;
    res.json({ reply });
  } catch (error) {
    console.error("Error en el chat:", error);
    res.status(500).json({ error: "Error procesando la solicitud" });
  }
});

app.listen(port, () => {
  console.log(`Servidor VIA corriendo en el puerto ${port}`);
});
